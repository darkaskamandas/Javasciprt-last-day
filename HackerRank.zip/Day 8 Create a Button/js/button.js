function change() {
  var p = document.getElementById('btn').innerHTML;
  p++;
  document.getElementById('btn').innerHTML = p;
}